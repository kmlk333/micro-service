package com.ITrator.eurekaclientfirst;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaClientFirstApplicationTests {

	@Test
	void contextLoads() {
	}

}
